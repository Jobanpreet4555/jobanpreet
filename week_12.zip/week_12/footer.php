<footer> <style>
   
</style>
 <p> Jobanpreet Singh | Student ID: 202106638</p>
    </a><a href="admin/login.php" class="admin-login-button">Admin Panel Login</a>
</footer>
