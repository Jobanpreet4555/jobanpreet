<?php
// edit-banner.php

// Database connection information
$host = "localhost";
$username = "root";
$password = "";
$dbname = "assignment2";

// Create connection
$conn = new mysqli($host, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Check if the form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Retrieve form data
    $banner_url = $_POST['banner_url'];

    // Update database
    $sql = "UPDATE banner SET header_background_image='$banner_url' WHERE id=1";
    if ($conn->query($sql) === TRUE) {
        header("Location: ../admin-index.php");
    } else {
        echo "Error updating banner image URL: " . $conn->error;
    }
}

// Fetch banner details
$banner_query = "SELECT * FROM banner WHERE id=1";
$banner_result = mysqli_query($conn, $banner_query);
$banner = mysqli_fetch_assoc($banner_result);
?>
