<?php
// Database connection information
$host = "localhost";
$username = "root";
$password = "";
$dbname = "assignment2";

// Create connection
$conn = new mysqli($host, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Check if the form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Retrieve form data
    $id = $_POST['id'];
    $title = $_POST['article_title'];
    $image_url = $_POST['article_image_url'];
    $content = $_POST['article_content'];

    // Update database
    $sql = "UPDATE articles SET title='$title', image_url='$image_url', content='$content' WHERE id=$id";
    if ($conn->query($sql) === TRUE) {
        header("Location: ../admin-index.php"); 
        exit();
    } else {
        echo "Error updating record: " . $conn->error;
    }
}

// Fetch article details based on ID
if(isset($_GET['id'])) {
    $id = $_GET['id'];
    $article_query = "SELECT * FROM articles WHERE id=$id";
    $article_result = mysqli_query($conn, $article_query);
    $article = mysqli_fetch_assoc($article_result);
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Article</title>
<style>
    body {
    font-family: Arial, sans-serif;
    background-color: #f4f4f4;
    margin: 0;
    padding: 0;
}

header {
    padding: 20px;
    text-align: center;
}

main {
    max-width: 800px;
    margin: 20px auto;
    padding: 20px;
    background-color: #fff;
    border-radius: 8px;
    box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
}

form {
    margin-top: 20px;
}

label {
    font-weight: bold;
}

input[type="text"],
textarea {
    width: 100%;
    padding: 10px;
    margin-top: 5px;
    margin-bottom: 15px;
    border: 1px solid #ccc;
    border-radius: 4px;
    box-sizing: border-box;
}

input[type="submit"],
button[type="button"] {
    padding: 10px 20px;
    border: none;
    border-radius: 4px;
    cursor: pointer;
}

input[type="submit"] {
    background-color: #4caf50;
    color: white;
}

button[type="button"] {
    background-color: #ccc;
    color: #555;
}

input[type="submit"]:hover {
    background-color: #45a049;
}

button[type="button"]:hover {
    background-color: #bbb;
}
</style>
</head>
<body>
    <header>
        <h1>Edit Article</h1>
    </header>
    <main>
        <section>
            <h2>Edit Article</h2>
            <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="post">
                <input type="hidden" name="id" value="<?php echo $article['id']; ?>">
                <label for="article_title">Title:</label><br>
                <input type="text" id="article_title" name="article_title" value="<?php echo $article['title']; ?>"><br>
                <label for="article_image_url">Image URL:</label><br>
                <input type="text" id="article_image_url" name="article_image_url" value="<?php echo $article['image_url']; ?>"><br>
                <label for="article_content">Content:</label><br>
                <textarea id="article_content" name="article_content" rows="4" cols="50"><?php echo $article['content']; ?></textarea><br>
                <input type="submit" value="Update">
                <a href="../admin-index.php"><button type="button">Cancel</button></a>

            </form>
        </section>
    </main>
</body>
</html>
